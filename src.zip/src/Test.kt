/**
 * Created by Matt on 10/1/2018.
 */
fun main(args: Array<String>) {
    val startTimes = intArrayOf(0, 3, 5, 7, 11, 19)
    val stopTimes = intArrayOf(3, 5, 7, 11, 14, 24)
    println(delta(startTimes, stopTimes))
}